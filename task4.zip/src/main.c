#include "functii.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

double pretP1[10000];
double pretP2[10000];
double pretP3[10000];

int cifra(char a) {
    if(a>='0' && a<='9')
        return 1;
    return 0;
}

int extragereNumar(const char *nume) {
    int nr=0;
    for(int i=0;nume[i]!='\0';i++)
        if(cifra(nume[i]))
            nr=nr*10+(nume[i]-'0');

    return nr;
}

double conversie(const char *s) {
    double rez=0.0;
    double factor=1.0;
    int i=0;
    int gasit=0;

    while(s[i]!='\0') {
        if(s[i]=='.')
            gasit=1;
        else if(cifra(s[i])) {
            if(!gasit)
                rez=rez*10.0+(s[i]-'0');
            else {
                factor/=10.0;
                rez=rez+(s[i]-'0')*factor;
            }
        }
        i++;
    }
    return rez; 
}

int main(int argc, const char *argv[]) {
    FILE *fin=fopen(argv[1], "r");
    FILE *fout=fopen(argv[2], "w");
    int nrFisier=extragereNumar(argv[1]);

    if(nrFisier>=1 && nrFisier<=5) {
        int N=0;
        struct Node* lista=NULL;
        double val;
        if(fscanf(fin, "%d", &N)==1) {
            for(int i=0;i<N;i++)
                if(fscanf(fin, "%lf", &val)==1)
                    adaugare_final(&lista, val);
        }
        if(N>=2) {
            calcul_randament(lista);
            double medie=calcul_randMediu(lista, N-1);
            double volatilitate=calcul_volatilitate(lista, medie, N-1);
            double sharpe_ratio=0.0;

            if(volatilitate!=0)
                sharpe_ratio=medie/volatilitate;

            fprintf(fout, "%.3lf\n", ((int)(medie*1000))/1000.0);
            fprintf(fout, "%.3lf\n", ((int)(volatilitate*1000))/1000.0);
            fprintf(fout, "%.3lf\n", ((int)(sharpe_ratio*1000))/1000.0);
        }
        eliberare_lista(lista);
    } else if(nrFisier>=6 && nrFisier<=10) {
        char numeP1[50];

        if(fscanf(fin, " %49[^\n]", numeP1)==1) {
            int n1=0;
            while(fscanf(fin, "%lf", &pretP1[n1])==1)
                n1++;
            char numeP2[50];
            fscanf(fin, " %49[^\n]", numeP2);
            int n2=0;
            while(fscanf(fin, "%lf", &pretP2[n2])==1)
                n2++;
            char numeP3[50];
            fscanf(fin, " %49[^\n]", numeP3);
            int n3=0;
            while(fscanf(fin, "%lf", &pretP3[n3])==1)
                n3++;
            oportunitati(
                pretP1, n1, numeP1,
                pretP2, n2, numeP2,
                pretP3, n3, numeP3,
                fout);
        }
    } else if(nrFisier>=11 && nrFisier<=15) {
        char nume[100][50];
        double pret[100][100];
        int N=0, zile=0;
        char buffer[5000];

        if(fscanf(fin, " %4999[^\n]", buffer)==1) {
            const char *p=strtok(buffer, ", \r\n");
            while(p!=NULL) {
                strcpy(nume[N], p);
                N++;
                p=strtok(NULL, ", \r\n");
            }
            zile=0;
        }
        while(fscanf(fin, " %4999[^\n]", buffer)==1) {
            if(strlen(buffer)<2)
                continue;
            int idx=0;
            const char *p=strtok(buffer, ", \r\n");
            while(p!=NULL && idx<N) {
                pret[idx][zile]=conversie(p);
                idx++;
                p=strtok(NULL, ", \r\n");
            }
            zile++;
        }
        portofoliu(nume, pret, N, zile, fout);
    } else if(nrFisier>=16 && nrFisier<=20) {
        int N,k;
        double d,p_start,p_target;
        if(fscanf(fin, "%d", &N)==1) {
            fscanf(fin, "%lf", &d);
            fscanf(fin, "%d", &k);
            fscanf(fin, "%lf", &p_start);
            fscanf(fin, "%lf", &p_target);

            double *preturi=(double*)malloc(N*sizeof(double));
            for(int i=0;i<N;i++)
                fscanf(fin, "%lf", &preturi[i]);
            Markov(N, d, k, p_start, p_target, preturi, fout);
            free(preturi);
        }
    }

    fclose(fin);
    fclose(fout);
    return 0;
}