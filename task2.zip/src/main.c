#include "functii.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

double pretP1[10000];
double pretP2[10000];
double pretP3[10000];

int main(int argc, const char *argv[]) {
    FILE *fin=fopen(argv[1], "r");
    FILE *fout=fopen(argv[2], "w");
    int N=0;
    
    if(fscanf(fin, "%d", &N)==1) {
        struct Node* lista=NULL;
        double val;

        for(int i=0;i<N;i++) 
            if(fscanf(fin, "%lf", &val)==1)
                adaugare_final(&lista, val);

        if(N<2) {
            eliberare_lista(lista);
            fclose(fin);
            fclose(fout);
            return 0;
        }

        calcul_randament(lista);
        double medie=calcul_randMediu(lista, N-1);
        double volatilitate=calcul_volatilitate(lista, medie, N-1);
        double sharpe_ratio=0.0;

        if(volatilitate!=0)
            sharpe_ratio=medie/volatilitate;

        fprintf(fout, "%.3lf\n", ((int)(medie*1000))/1000.0);
        fprintf(fout, "%.3lf\n", ((int)(volatilitate*1000))/1000.0);
        fprintf(fout, "%.3lf\n", ((int)(sharpe_ratio*1000))/1000.0);

        eliberare_lista(lista);
    } else {
        char numeP1[50],numeP2[50],numeP3[50];
        int n1=0,n2=0,n3=0;

        if(fscanf(fin, " %49[^\n]", numeP1)!=1) {
            fclose(fin);
            fclose(fout);
            return 0;
        }

        while(fscanf(fin, "%lf", &pretP1[n1])==1)
            n1++;
        fscanf(fin, " %49[^\n]", numeP2);
        while(fscanf(fin, "%lf", &pretP2[n2])==1)
            n2++;
        fscanf(fin, " %49[^\n]", numeP3);
        while(fscanf(fin, "%lf", &pretP3[n3])==1)
            n3++;

        oportunitati(
            pretP1, n1, numeP1,
            pretP2, n2, numeP2,
            pretP3, n3, numeP3,
            fout);
    }

    fclose(fin);
    fclose(fout);
    return 0;
}